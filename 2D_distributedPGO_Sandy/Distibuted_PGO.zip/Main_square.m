% Main function for the square world test
clear; clc; close all

pudq_pgo_lib_path = [pwd '/Pudq_lib'];
addpath(pudq_pgo_lib_path)

% Parameters
seed             = 317;
rng(seed);

num_robots       = 3;
sigma_pudq       = 1e-2;
side_len         = 5;
gap              = 2;
inter_lc_prob    = 0.1;
lambda            = 1;
N_max            = 800000;
alpha_init       = 1e-2;
grad_tol         = 1e-2;
lambda_reg       = 1e-4;

graph = generate_pudq_squareworld_multirobot_2d(num_robots, sigma_pudq, side_len , gap, inter_lc_prob);

disp('Square world graph generation complete.');

multi_graph = distributebiggraph(graph, num_robots);
% plot_bigworld_with_distributedinfo(graph, multi_graph, num_robots);
% return
robot = struct;
for r = 1: num_robots
    local_graph = build_local_subgraph(multi_graph, r);

    [rgrad_0, ~, F_0] = rgn_gradhess_multi_J(local_graph);
    gradnorm_0 = norm(rgrad_0);

    robot(r).id = r;
    robot(r).local_graph = local_graph;
    robot(r).rgn_cost = F_0;
    robot(r).rgn_gradnorm = gradnorm_0;
    robot(r).converge = false;
end

        
% fprintf('\n=== BOUMAL GRADIENT CHECK BEFORE OPTIMIZATION ===\n');
% for r = 1:num_robots
%     fprintf('\n--- Checking Robot %d (Pre-optimization) ---\n', r);
%     boumal_check_multirobot(robot(r).local_graph, r);
% end
% fprintf('\n=== END PRE-OPTIMIZATION BOUMAL CHECKS ===\n');

% for r = 1:num_robots
%     R0 = boumal_check_multirobot2(robot(r).local_graph, 'num_dirs',4, 'make_plot',true);
%     assert(~isempty(R0.median_slope) && abs(R0.median_slope-2)<0.4, ...
%         'Robot %d gradient check failed at init.', r);
% end

% %% true info %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         for r = 1:num_robots
%              robot(r).local_graph.inter_dp_pudq = robot(r).local_graph.inter_dp_pudq_true;
%              robot(r).local_graph.inter_info = eye(3); 
%              robot(r).local_graph.intra_dp_pudq = robot(r).local_graph.intra_dp_pudq_true;
%              robot(r).local_graph.intra_info = eye(3); 
%          end
        %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global_time = 0;
robot_time = exprnd (1/lambda, [1, num_robots]);

for iter = 1 : N_max
    [global_time, r] = min(robot_time);


%     for edge_idx = 1:size(robot(r).local_graph.inter_edges, 2)
%          i = robot(r).local_graph.inter_edges(1, edge_idx); % Local pose index
%          L = robot(r).local_graph.inter_edges(2, edge_idx); % Landmark index
% 
%          lm_r = robot(r).local_graph.lm_foreign_info{L}.robot;
%          lm_v = robot(r).local_graph.lm_foreign_info{L}.vertex;
% 
%          robot(r).local_graph.lm_vertices_pudq{L} = robot(lm_r).local_graph.vertices_pudq{lm_v};
%          robot(r).local_graph.lm_vertices{L} = robot(lm_r).local_graph.vertices{lm_v};
%     end


    [local_graph, F_now, norm_grad_F] = Optimization_RGN_linesearch(robot(r).local_graph, alpha_init, grad_tol, lambda_reg);
    robot(r).local_graph      = local_graph;
    robot(r).rgn_cost(end+1)     = F_now;
    robot(r).rgn_gradnorm(end+1) = norm_grad_F;


%     if mod(iter, 5) == 0
%             Rk = boumal_check_multirobot2(robot(r).local_graph, 'num_dirs', 2, 'make_plot', false);
%             fprintf('Boumal check @ iter %d | Robot %d | slope=%.2f\n', ...
%                     iter, r, Rk.median_slope);
% 
%             % Optional: warning if gradient seems wrong
%             if ~isnan(Rk.median_slope) && abs(Rk.median_slope - 2.0) > 0.4
%                 error('Robot %d: suspicious gradient slope = %.2f at iter %d', ...
%                         r, Rk.median_slope, k);
%             end
%    end

    robot = shareupdateinfo(r, local_graph, robot);

    robot_time(r) = global_time + exprnd(1/lambda);
    fprintf('Iter=%3d -> Robot %d updated  (F=%.3g, grad=%.3g)\n', iter, r, F_now, norm_grad_F);

    robot = check_all_robotgrad(robot, grad_tol);

    if all([robot.converge])
        fprintf('All %d robots converged -> terminating at iter=%d.\n', numel(robot), iter);
        break;
    end

end

fprintf('\n*** Done with %d asynchronous update events! ***\n', N_max);

for r = 1:num_robots
    R0 = boumal_check_multirobot2(robot(r).local_graph, 'num_dirs',4, 'make_plot',true);
    assert(~isempty(R0.median_slope) && abs(R0.median_slope-2)<0.4, ...
        'Robot %d gradient check failed at init.', r);
end



figure('Name','Per-Robot Cost','NumberTitle','off');
hold on; grid on;
colors = lines(num_robots);

for r = 1:num_robots
    N = length(robot(r).rgn_cost) - 1;
    plot_indices = linspace(0, N, N+1);
    
    plot( plot_indices, robot(r).rgn_cost,'Color', colors(r,:), 'LineWidth', 1.25, 'DisplayName', sprintf('Robot %d', r) );
end

% set(gca, 'YScale', 'log');
title('Per-Robot Cost vs. iteration (Asynchronous Poisson updates)', 'FontSize', 14);
xlabel('Local iteration count', 'FontSize', 12);
ylabel('RGD Cost',              'FontSize', 12);
legend('show', 'Location','best');
ax = gca;
ax.YAxis.TickLabelFormat = '10^{%g}';

hold off;

figure('Name','Per-Robot Grad Norm','NumberTitle','off');
hold on; grid on;

for r = 1:num_robots
    N = length(robot(r).rgn_gradnorm) - 1;
    plot_indices = linspace(0, N, N+1);
    
    plot( plot_indices, robot(r).rgn_gradnorm, 'Color', colors(r,:),'LineWidth', 1.25, 'DisplayName', sprintf('Robot %d', r) );
end

set(gca, 'YScale', 'log');
title('Per-Robot Gradient Norm (Asynchronous Poisson)', 'FontSize', 14);
xlabel('Local iteration count', 'FontSize', 12);
ylabel('RGD Gradient norm',    'FontSize', 12);
legend('show', 'Location','best');
ax = gca;
ax.YAxis.TickLabelFormat = '10^{%g}';

hold off;
% 
% figure('Name','Per-Robot Grad Norm (Global)','NumberTitle','off');
% set(gca, 'YScale', 'log');

% hold on; grid on;
% for r = 1:num_robots
%     semilogy(1:numel(robot(r).rgn_gradnorm_global), robot(r).rgn_gradnorm_global, '-', 'LineWidth', 1.5, ...
%              'Color', colors(r,:), 'DisplayName', sprintf('Robot %d', r));  
% end
% xlabel('Global async event'); ylabel('RGN gradient norm');
% legend('show', 'Location','best');
% ax = gca;
% title('Per-robot gradient (every iteration)');
% hold off;














