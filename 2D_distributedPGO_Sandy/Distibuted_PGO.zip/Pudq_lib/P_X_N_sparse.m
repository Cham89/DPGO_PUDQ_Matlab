function P = P_X_N_sparse(X)

    %Note: This function expects X to be a cell array of PUDQ vertices
    N = length(X);

    % Initialize P_X triplets (N 4x4 matrices worth of elements in P_X)
    num_triplets = 16*N;
    t_id = 0;
    i_triplets = zeros(num_triplets, 1);
    j_triplets = zeros(num_triplets, 1);
    v_triplets = zeros(num_triplets, 1);

    % P_array = cell(N);

    for v=1:N
        % Each P_x is a 4x4 sparse matrix
        x_i = X{v};
        P_x = [eye(2) - x_i(1:2)*x_i(1:2)', zeros(2,2); zeros(2,2), eye(2)];

        for i=1:4
            for j=1:4
                t_id = t_id+1;
                i_triplets(t_id) = 4*(v-1)+i;
                j_triplets(t_id) = 4*(v-1)+j;
                v_triplets(t_id) = P_x(i,j);
            end
        end

        % P_array{v} = P_x;
    end
    
    % P = blkdiag(P_array{:});
    P = sparse(i_triplets, j_triplets, v_triplets, 4*N, 4*N);
end
